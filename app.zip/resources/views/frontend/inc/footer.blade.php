
    <footer class="py-3 px-4 hfooter no-print">
        <div class="container">
         <div class="col-md-10 mx-auto">
            <div class="row">
                <div class="col-md-4 py-4 text-white">
                    <h6 class="text-info">Contact & Info</h6>
                 <ul class="list-unstyled mb-0">
                     <li>
                        <a  class="text-white text-decoration-none"href="tel:+44 (0)20 8731 8988">
                            <i class="fa fa-phone"></i>
                            +44 7490956227</a>
                     </li>
                     <li>
                        <a  class="text-white text-decoration-none"href="mailto:admin@admin.com">
                            <i class="fa fa-envelope-o" aria-hidden="true"></i> 
                                tevinivouchers@gmail.com</a>
                     </li>
                     <!--<li class="  text-decoration-none">-->
                     <!--   Reg. Charity No. XXXXXX-->
                     <!--</li>-->
                     
                    
                 </ul>
                </div>
                 
                <div class="col-md-4 py-4 text-white">
                    <h6  class="text-info">Address Info</h6>
                 <ul class="list-unstyled mb-0"> 
                     <li class="  text-decoration-none">
                         5A Holmdale Terrace <br>    London, N15 6PP 
                     </li>
                   
                    
                 </ul>
                </div>
                <div class="col-md-4 py-4">
                    <h6  class="text-light">Regular Links</h6>
                 <ul class="list-unstyled mb-0">
                    
                      <li> <a href="{{ route('terms') }}" class="text-decoration-none">Terms & condition</a>
                     </li>
                     <li>
                       <a href="#!" class="text-decoration-none">Privacy Policy</a>
                     </li>
                 </ul>
                </div>
              
               
            </div>
         </div>
            <hr class="my-4" style="background:rgba(255,255,255,0.5)">
            <div class="space-1">
                <!-- Copyright -->
                <div class="text-center">
                    <p class="mb-0 small text-white">Copyright© 2022 Teveni All rights reserved.</p>
                </div>
                <div class="text-center">
                    <p class="mb-0 small text-white">Design & Developed by : MentoSoftware</a></p>
                </div>
                <!-- End Copyright -->
            </div>
        </div>
    </footer>