@extends('frontend.layouts.master')

@section('content')



<div id="header-top">
    <div class="featured-image">
            </div>
    <div class="container">

        <div class="col-xs-12 col-sm-10 col-sm-offset-1 col-md-10 col-md-offset-1 centered cont-title">

            <div class="header">
                <h2>Meet the Team</h2>
                <h3>What is Lorem Ipsum What is Lorem IpsumWhat is Lorem Ipsum.What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum</h3>
            </div>

        </div><!-- /cont-title -->


        <!-- Nav tabs -->

        <ul class="nav nav-tabs" role="tablist">
            <li role="presentation" class="active"><a href="#trustees" aria-controls="trustees" role="tab" data-toggle="tab">Trustees</a></li>
            <li role="presentation"><a href="#staff" aria-controls="staff" role="tab" data-toggle="tab">Our Staff</a></li>

        </ul>

    </div><!-- /container -->

</div><!-- /header-top -->

<div class="tab-content">
    <div role="tabpanel" class="tab-pane fadea active in" id="trustees">

        <div class="container">


        <div class="row">


                                            <div class="col-md-4">
                            <div class="team-card">
                                <div class="position">Chairman</div>
                                <div class="name">ABC DEF</div>
                                <a href="mailto:y.katz@achisomoch.org" class="mail">admin@admin.com</a>
                                <div class="description content-show-more more" data-chars="45" >
                                    <p>What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum</p>
                                </div>
                            </div>
                        </div>

                                            <div class="col-md-4">
                            <div class="team-card">
                                <div class="position">Trustee</div>
                                <div class="name">ABC XYZ</div>
                                <a href="mailto:" class="mail"></a>
                                <div class="description content-show-more more" data-chars="45" >
                                    <p>What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum</p>
                                </div>
                            </div>
                        </div>

                                            <div class="col-md-4">
                            <div class="team-card">
                                <div class="position">Trustee</div>
                                <div class="name">Abc Xyz</div>
                                <a href="mailto:" class="mail"></a>
                                <div class="description content-show-more more" data-chars="45" >
                                    <p>What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum</p>
                                </div>
                            </div>
                        </div>

                                            <div class="col-md-4">
                            <div class="team-card">
                                <div class="position">Trustee</div>
                                <div class="name">Xyz Abc</div>
                                <a href="mailto:" class="mail"></a>
                                <div class="description content-show-more more" data-chars="45" >
                                    <p>What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum</p>
                                </div>
                            </div>
                        </div>

                                            <div class="col-md-4">
                            <div class="team-card">
                                <div class="position">Trustee</div>
                                <div class="name">Abc Xyz</div>
                                <a href="mailto:r.denton@achisomoch.org" class="mail">r.denton@achisomoch.org</a>
                                <div class="description content-show-more more" data-chars="45" >
                                    <p>What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum</p>
                                </div>
                            </div>
                        </div>











                                                </div><!-- / row -->

        </div><!-- /container -->
    </div>
    <div role="tabpanel" class="tab-pane fade " id="staff">

        <div class="container">

            <div class="row">







                                                    <div class="col-md-4">
                                <div class="team-card">
                                    <div class="position">CEO</div>
                                    <div class="name">Xyz Abc</div>
                                    <a href="mailto:admin@admin.org" class="mail">admin@amin.com</a>
                                    <div class="description content-show-more " data-chars="45" >
                                        <p>What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum.</p>
                                    </div>
                                </div>
                            </div>

                                                    <div class="col-md-4">
                                <div class="team-card">
                                    <div class="position">Co-Deputy Head of Operations</div>
                                    <div class="name">Aidel Katzel</div>
                                    <a href="mailto:admin@admin.com" class="mail">admin@admin.com</a>
                                    <div class="description content-show-more " data-chars="45" >
                                        <p>What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum</p>
                                    </div>
                                </div>
                            </div>

                                                    <div class="col-md-4">
                                <div class="team-card">
                                    <div class="position">Co-Deputy Head of Operations </div>
                                    <div class="name">Xyz Abc</div>
                                    <a href="mailto:admin@admin.com" class="mail">admin@admin.com</a>
                                    <div class="description content-show-more " data-chars="45" >
                                        <p>What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum</p>
                                    </div>
                                </div>
                            </div>

                                                    <div class="col-md-4">
                                <div class="team-card">
                                    <div class="position">Head of IT</div>
                                    <div class="name">Isi Schnitzer</div>
                                    <a href="mailto:admin@admin.com" class="mail">admin@admin.com</a>
                                    <div class="description content-show-more " data-chars="45" >
                                        <p>What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum</p>
                                    </div>
                                </div>
                            </div>

                                                    <div class="col-md-4">
                                <div class="team-card">
                                    <div class="position">Project Manager</div>
                                    <div class="name">Abc Xyz</div>
                                    <a href="mailto:admin@admin.com" class="mail">admin@admin.com</a>
                                    <div class="description content-show-more " data-chars="45" >
                                        <p>What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum</p>
                                    </div>
                                </div>
                            </div>

                                                    <div class="col-md-4">
                                <div class="team-card">
                                    <div class="position">IT Developer</div>
                                    <div class="name">David Mirwis</div>
                                    <a href="mailto:admin@admin.com" class="mail">admin@admin.com</a>
                                    <div class="description content-show-more " data-chars="45" >
                                        <p>What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum.</p>
                                    </div>
                                </div>
                            </div>

                                                    <div class="col-md-4">
                                <div class="team-card">
                                    <div class="position">IT Developer</div>
                                    <div class="name">Shalom Solomon</div>
                                    <a href="mailto:admin@admin.com" class="mail">s.solomon@achisomoch.org</a>
                                    <div class="description content-show-more " data-chars="45" >
                                        <p>What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum</p>
                                    </div>
                                </div>
                            </div>

                                                    <div class="col-md-4">
                                <div class="team-card">
                                    <div class="position">Compliance Administrator</div>
                                    <div class="name">Abc Xyz</div>
                                    <a href="mailto:admin@admin.com" class="mail">admin@admin.com</a>
                                    <div class="description content-show-more " data-chars="45" >
                                        <p>What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum</p>
                                    </div>
                                </div>
                            </div>

                                                    <div class="col-md-4">
                                <div class="team-card">
                                    <div class="position">Compliance Administor</div>
                                    <div class="name">Julia Vilensky</div>
                                    <a href="mailto:admin@admin.com" class="mail">admin@admin.com</a>
                                    <div class="description content-show-more " data-chars="45" >
                                        <p>What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem <br />
                                            What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum </p>
                                    </div>
                                </div>
                            </div>

                                                    <div class="col-md-4">
                                <div class="team-card">
                                    <div class="position">Administrator</div>
                                    <div class="name">ABC XYZ</div>
                                    <a href="mailto:admin@admin.com" class="mail">admin@admin.com</a>
                                    <div class="description content-show-more " data-chars="45" >
                                        <p>What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What</p>
                                    </div>
                                </div>
                            </div>

                                                    <div class="col-md-4">
                                <div class="team-card">
                                    <div class="position">Administrator</div>
                                    <div class="name">Esther Guttentag</div>
                                    <a href="mailto:admin@admin.com" class="mail">admin@admin.com</a>
                                    <div class="description content-show-more " data-chars="45" >
                                        <p>What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What.</p>
                                    </div>
                                </div>
                            </div>
                        	</div><!-- / row -->

        </div><!-- /container -->

    </div>
</div>

<div id="some-questions" class="row hidden-xs">

		<div class="container">

			<div class="col-sm-8 col-sm-offset-2  col-md-9 col-md-offset-1 col-lg-8 col-lg-offset-2 centered">

				<div class="header">

					<h2>Frequently Asked Questions</h2>

				</div>

			</div>

			<div class="col-sm-12  col-md-10 col-md-offset-1 centered">

				<ul id="accordion">




					<li class="">

						<div class="title-box">

							<a href="#">

								What commission rate does Achisomoch charge?
								<span class="icon-open"><i class="fa fa-angle-up"></i></span>
								<span class="icon-close"><i class="fa fa-angle-down"></i></span>

							</a>

						</div><!-- /title-box-->

						<div class="info-box">

							<p>What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum.</p>

						</div><!-- /info-box-->

					</li>



					<li class="">

						<div class="title-box">

							<a href="#">

								How can I see how much I have in my account?
								<span class="icon-open"><i class="fa fa-angle-up"></i></span>
								<span class="icon-close"><i class="fa fa-angle-down"></i></span>

							</a>

						</div><!-- /title-box-->

						<div class="info-box">

							<p>What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum</p>

						</div><!-- /info-box-->

					</li>



					<li class="">

						<div class="title-box">

							<a href="#">

								How long does it take for the donation to arrive at the charity
								<span class="icon-open"><i class="fa fa-angle-up"></i></span>
								<span class="icon-close"><i class="fa fa-angle-down"></i></span>

							</a>

						</div><!-- /title-box-->

						<div class="info-box">

							<p>What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum.</p>

						</div><!-- /info-box-->

					</li>



					<li class="">

						<div class="title-box">

							<a href="#">

								How do I find out more?
								<span class="icon-open"><i class="fa fa-angle-up"></i></span>
								<span class="icon-close"><i class="fa fa-angle-down"></i></span>

							</a>

						</div><!-- /title-box-->

						<div class="info-box">

							<p>Clients may communicate with us using e-mail (<a href="mailto:admin@admin.com"><strong>admin@admin.com</strong></a>) or phone during Office hours, Monday &#8211; Thursday: 9:30 am &#8211; 5:00 pm and Friday: 9:30 am &#8211; 12:00pm.</p>

						</div><!-- /info-box-->

					</li>



					<li class="">

						<div class="title-box">

							<a href="#">

								How about donations to charities abroad?
								<span class="icon-open"><i class="fa fa-angle-up"></i></span>
								<span class="icon-close"><i class="fa fa-angle-down"></i></span>

							</a>

						</div><!-- /title-box-->

						<div class="info-box">

							<p>What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum What is Lorem Ipsum.</p>

						</div><!-- /info-box-->

					</li>



					<li class="">

						<div class="title-box">

							<a href="#">

								Where can I find out more about Gift Aid?
								<span class="icon-open"><i class="fa fa-angle-up"></i></span>
								<span class="icon-close"><i class="fa fa-angle-down"></i></span>

							</a>

						</div><!-- /title-box-->

						<div class="info-box">

							<p>You can find out more about Gift Aid <a href="https://www.gov.uk/donating-to-charity/gift-aid">here</a>.</p>

						</div><!-- /info-box-->

					</li>


				</ul>

			</div><!-- /col 12 -->

		</div><!-- /container -->

    </div><!-- /row -->


@endsection


