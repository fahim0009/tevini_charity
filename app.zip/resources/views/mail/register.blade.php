<div class="container">
  Hi {{$array['name']}},<br>
 
  Welcome to Tevini

 <p> We are pleased to welcome you as a client of Tevini. You can log into your account at <a href="https://www.tevini.co.uk/">www.Tevini.co.uk</a>Here are a few rules to help you use our service.</p>
  
 <ul>
    <li>Voucher books should be ordered via your online account </li>
    <li>When you write a voucher, please ensure that it is fully and clearly completed and signed.</li>
    <li>Donations made to charities via your account online will usually reach the charity a lot quicker than a voucher.</li>
    <li>Gift Aid claims are submitted monthly. all your transactions will be available to view on your account online, which is updated at various intervals throughout working days.</li>
</ul>
</div>