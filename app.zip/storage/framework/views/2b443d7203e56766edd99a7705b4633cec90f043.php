<?php $__env->startSection('content'); ?>
<?php
use Illuminate\Support\Carbon;
?>
<div class="dashboard-content">
    <section class="profile purchase-status">
        <div class="title-section">
            <span class="iconify" data-icon="icon-park-outline:transaction"></span> <div class="mx-2">Donor Details</div>
        </div>
    </section>
    <?php echo $__env->make('inc.user_menue', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <section class="">
    <div class="row  my-3 mx-0 ">
        <div class="col-md-12 ">
            <nav>
                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                  <button class="nav-link active" id="all-tab" data-bs-toggle="tab" data-bs-target="#nav-transactionAll" type="button" role="tab" aria-controls="nav-all" aria-selected="true">All Transaction</button>
                  <button class="nav-link" id="transactionOut-tab" data-bs-toggle="tab" data-bs-target="#nav-transactionOut" type="button" role="tab" aria-controls="nav-home" aria-selected="true">Transaction In</button>
                  <button class="nav-link" id="nav-profile-tab" data-bs-toggle="tab" data-bs-target="#nav-transcationIn" type="button" role="tab" aria-controls="nav-profile" aria-selected="false">Transcation Out</button>
                </div>
              </nav>
              <div class="tab-content" id="nav-tabContent">
                <div class="tab-pane fade show active" id="nav-transactionAll" role="tabpanel" aria-labelledby="nav-all">
                    <div class="row my-2">
                        <div class="col-md-12 my-3">
                            <div class="container">
                           <div class="row">
                            <div class="col-md-9">
                                <form class="form-inline" action="<?php echo e(route('search.donortran', $donor_id)); ?>" method ="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">

                                        <div class="col-md-3">
                                            <div class="form-group my-2">
                                                <label for="fromDate"><small>Date From </small> </label>
                                                <input class="form-control mr-sm-2" id="fromDate" name="fromDate" type="date" placeholder="Search" aria-label="Search">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group my-2">
                                                <label for="toDate"><small>Date To </small> </label>
                                                <input class="form-control mr-sm-2" id="toDate" name="toDate" type="date" placeholder="Search" aria-label="Search">
                                            </div>
                                        </div>
                                        <div class="col-md-5 d-flex align-items-center">
                                            <div class="form-group d-flex mt-4">
                                            <button class="text-white btn-theme ml-1" type="submit">Search</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            </div>

                           </div>
                        </div>
                        <div class="col-md-12 mt-2 text-center">
                            <div class="overflow">
                                <table class="table table-custom shadow-sm bg-white">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Transaction Id</th>
                                            <th>transaction type</th>
                                            <th>Voucher Number</th>
                                            <th>Charity Name</th>
                                            <th>Status</th>
                                            <th>Credit</th>
                                            <th>Debit</th>
                                            <th>Balance</th>
                                        </tr>
                                    </thead>

                                <?php
                                    $tbalance = 0;
                                ?>

                                  <?php $__currentLoopData = $tamount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($data->commission != 0): ?>
                                            <?php
                                            $tbalance = $tbalance - $data->commission;
                                            ?>
                                        <?php endif; ?>

                                        <?php
                                        if($data->t_type == "In"){
                                            if($data->commission != 0){

                                            $tbalance = $tbalance + $data->amount + $data->commission;
                                            }else {

                                            $tbalance = $tbalance + $data->amount;
                                            }

                                        }
                                        ?>
                                                <?php
                                                if($data->t_type == "Out"){
                                                $tbalance = $tbalance - $data->amount;
                                                }
                                                ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <tbody>
                                    <?php $__currentLoopData = $report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($data->commission != 0): ?>
                                        <tr>
                                            <td><?php echo e(Carbon::parse($data->created_at)->format('d/m/Y')); ?></td>
                                            <td><?php echo e($data->t_id); ?> </td>
                                            <td>Commission</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>-£<?php echo e($data->commission); ?></td>
                                            <td>£<?php echo e(number_format($tbalance, 2)); ?></td>
                                            <?php
                                            $tbalance = $tbalance + $data->commission;
                                            ?>
                                        </tr>
                                        <?php endif; ?>
                                        <tr>
                                            <td><?php echo e(Carbon::parse($data->created_at)->format('d/m/Y')); ?></td>
                                            <td><?php echo e($data->t_id); ?> </td>
                                            <td><?php echo e($data->title); ?> </td>
                                            <td><?php echo e($data->cheque_no); ?></td>
                                            <td><?php if($data->charity_id): ?><?php echo e($data->charity->name); ?><?php endif; ?></td>
                                            <td><?php if($data->pending == "0"): ?> Pending <?php endif; ?></td>

                                                <?php if($data->t_type == "In"): ?>
                                                    <?php if($data->commission != 0): ?>
                                                        <td>£ <?php echo e(number_format($data->amount + $data->commission, 2)); ?> </td>
                                                        <td></td>
                                                        <td> £<?php echo e(number_format($tbalance, 2)); ?> </td>
                                                        <?php $tbalance = $tbalance - $data->amount - $data->commission; ?>
                                                    <?php else: ?>
                                                        <td>£<?php echo e(number_format($data->amount, 2)); ?> </td>
                                                        <td></td>
                                                        <td> £<?php echo e(number_format($tbalance, 2)); ?> </td>
                                                        <?php $tbalance = $tbalance - $data->amount; ?>
                                                    <?php endif; ?>
                                                <?php elseif($data->t_type == "Out"): ?>
                                                    <td></td>
                                                    <td>-£<?php echo e(number_format($data->amount, 2)); ?></td>
                                                     <td> £<?php echo e(number_format($tbalance, 2)); ?> </td>
                                                     <?php if($data->pending != "0"): ?>
                                                     <?php  $tbalance = $tbalance + $data->amount;  ?>
                                                     <?php endif; ?>
                                                <?php endif; ?>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td>Previous Balance</td>
                                        <td>£<?php echo e(number_format($tbalance, 2)); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="tab-pane fade show" id="nav-transactionOut" role="tabpanel" aria-labelledby="nav-transactionOut">
                    <div class="row my-2">
                        <div class="col-md-12 my-3">
                            <div class="container">
                           <div class="row">
                            <div class="col-md-9">
                                <form class="form-inline" action="<?php echo e(route('search.donortran', $donor_id)); ?>" method ="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">

                                        <div class="col-md-3">
                                            <div class="form-group my-2">
                                                <label for="fromDate"><small>Date From </small> </label>
                                                <input class="form-control mr-sm-2" id="fromDate" name="fromDate" type="date" placeholder="Search" aria-label="Search">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group my-2">
                                                <label for="toDate"><small>Date To </small> </label>
                                                <input class="form-control mr-sm-2" id="toDate" name="toDate" type="date" placeholder="Search" aria-label="Search">
                                            </div>
                                        </div>
                                        <input type="hidden" name="donor_id" id="donor_id" value="<?php echo e($user->id); ?>">
                                        <div class="col-md-5 d-flex align-items-center">
                                            <div class="form-group d-flex mt-4">
                                            <button class="text-white btn-theme ml-1" type="submit">Search</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                                </div>
                                </div>
                           </div>
                        </div>
                        <div class="col-md-12 mt-2 text-center">
                            <div class="overflow">
                                <table class="table table-custom shadow-sm bg-white" id="example">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Transaction Id</th>
                                            <th>Source</th>
                                            <th>Commission</th>
                                            <th>Amount </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $intransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                                <td><span style="display:none;"><?php echo e($transaction->id); ?></span><?php echo e(Carbon::parse($transaction->created_at)->format('d/m/Y')); ?></td>
                                                <td><?php echo e($transaction->t_id); ?></td>
                                                <td><?php echo e($transaction->source); ?></td>
                                                <td>£<?php echo e($transaction->commission); ?></td>
                                                <td>£<?php echo e($transaction->amount); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade" id="nav-transcationIn" role="tabpanel" aria-labelledby="nav-profile-tab">
                    <div class="row my-2">
                        <div class="col-md-12 my-3">
                            <div class="col-md-12 my-3">
                                <div class="container">
                               <div class="row">
                                <div class="col-md-9">
                                    <form class="form-inline" action="<?php echo e(route('search.donortran', $donor_id)); ?>" method ="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="row">

                                            <div class="col-md-3">
                                                <div class="form-group my-2">
                                                    <label for="fromDate"><small>Date From </small> </label>
                                                    <input class="form-control mr-sm-2" id="fromDate" name="fromDate" type="date" placeholder="Search" aria-label="Search">
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group my-2">
                                                    <label for="toDate"><small>Date To </small> </label>
                                                    <input class="form-control mr-sm-2" id="toDate" name="toDate" type="date" placeholder="Search" aria-label="Search">
                                                </div>
                                            </div>
                                            <input type="hidden" name="donor_id" id="donor_id" value="<?php echo e($user->id); ?>">
                                            <div class="col-md-5 d-flex align-items-center">
                                                <div class="form-group d-flex mt-4">
                                                <button class="text-white btn-theme ml-1" name="search" title="Search" type="submit">Search</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                    </div>
                                </div>
                               </div>
                            </div>
                        </div>
                        <div class="col-md-12 mt-2 text-center">
                            <div class="overflow">
                                <table class="table table-custom shadow-sm bg-white" id="exampleIn">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Transaction Id</th>
                                            <th>Charity Name</th>
                                            <th>Voucher Number</th>
                                            <th>Status</th>
                                            <th>Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $outtransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><span style="display:none;"><?php echo e($transaction->id); ?></span><?php echo e(Carbon::parse($transaction->created_at)->format('d/m/Y')); ?></td>
                                            <td><?php echo e($transaction->t_id); ?></td>
                                            <td><?php if($transaction->charity_id): ?><?php echo e($transaction->charity->name); ?><?php endif; ?></td>
                                            <td><?php echo e($transaction->cheque_no); ?></td>
                                            <td><?php if($transaction->pending == "0"): ?> Pending <?php endif; ?></td>
                                            <td>£<?php echo e($transaction->amount); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
              </div>
        </div>
    </div>
  </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\server\htdocs\Laravel\tevini_charity\resources\views/donor/transaction.blade.php ENDPATH**/ ?>