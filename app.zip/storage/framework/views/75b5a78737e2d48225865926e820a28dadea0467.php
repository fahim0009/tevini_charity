<footer class="py-3 w-100 no-print">
    <div class="container">
        <div class="d-flex flex-wrap w-100 mx-auto">

            <div class=" flex-fill bd-highlight ">
                <ul class="m-0 text-white">
                    <!--<li class="list-style-none">+44 (0)xx xxxx 8xxxx</li>-->
                    <!--<li class="list-style-none">support@admin.com</li>-->
                    <!--<li class="list-style-none"> address goes here </li>-->
                </ul>
            </div>

            
            <div class="p-2 flex-fill bd-highlight">
                <img src="<?php echo e(asset('assets/image/logo/logo.png')); ?>" width="160px">
            </div>


            <div class="p-2 d-flex align-items-center footerContact">
                <!--<a href="" class="mx-2 text-decoration-none text-white">Help</a>-->
                <!--<a href="" class="mx-2 text-decoration-none text-white">Contact</a>-->
            </div>
        </div>
    </div>
</footer>
<?php /**PATH D:\server\htdocs\Laravel\tevini_charity\resources\views/inc/admin_footer.blade.php ENDPATH**/ ?>