<?php $__env->startSection('content'); ?>
<?php
use Illuminate\Support\Carbon;
use app\Models\Provoucher;
?>
<?php echo $__env->make('inc.user_menue', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="rightSection" id="section-to-print">

    <div class="dashboard-content">
        <section class="profile purchase-status">
            <div class="title-section">
                <span class="iconify" data-icon="et:wallet"></span>
                <div class="mx-2">
                  Donor Report
                </div>
            </div>
        </section>
        <!-- Image loader -->
        <div id='loading' style='display:none ;'>
            <img src="<?php echo e(asset('assets/image/loader.gif')); ?>" id="loading-image" alt="Loading..." />
       </div>
     <!-- Image loader -->
     <div class="ermsg"></div>

        <section class="px-4">
            <div class="row no-print">
            <div class="col-12">
                <button onclick="window.print()" class="fa fa-print btn btn-default float-end">Print</button>
            </div>
            </div>

            <div class="row my-3">
                <div class="col-md-12 mt-2 ">

                    <div class="text-start mb-4 px-2">

                        <p class="mb-1" id="charityname"><?php echo e($user->name); ?></p>
                        <p class="mb-1" id="charityaddress"><?php echo e($user->street); ?></p>
                        <p class="mb-1" id="charityaddress"><?php echo e($user->town); ?></p>

                    </div>

                    <div class="d-flex justify-content-between no-print align-items-center flex-wrap">

                        <div class="text-start mb-1 flex-fill">
                            <form  action="<?php echo e(route('donor.reportsearch', $user->id)); ?>" method ="POST" class="d-flex justify-content-around align-items-center flex-wrap">
                                <?php echo csrf_field(); ?>
                                <div class="form-group my-2 mx-1 flex-fill">
                                    <label for=""><small>Date From </small> </label>
                                    <input class="form-control no-print mr-sm-2" type="date" id="fromdate" name="fromdate" placeholder="Search" aria-label="Search">
                                </div>

                                <div class="form-group my-2 mx-1 flex-fill">
                                    <label for=""><small>Date To </small> </label>
                                    <input class="form-control mr-sm-2 no-print" type="date" id="todate" name="todate" placeholder="Search" aria-label="Search">
                                </div>
                                <input type="hidden" name="charityid" id="charityid" class="charityid">

                                <div class="form-group my-2 mx-1 flex-fill">
                                    <button class="text-white btn-theme no-print ml-1 mt-4"  class="btn" name="search" title="Search" type="submit">Search</button>
                                </div>

                           </form>

                           <div  class="d-flex justify-content-around align-items-center flex-wrap">
                            <?php echo csrf_field(); ?>

                            <input type="hidden" name="user_id" id="user_id" value="<?php echo e($user->id); ?>">
                            <input  type="hidden" id="efromdate" name="fromdate" value="<?php echo e($fromDate); ?>">
                            <input  type="hidden" id="etodate" name="todate" value="<?php echo e($toDate); ?>">
                            <div class="form-group my-2 mx-1 flex-fill">
                                <label for=""><small>Donor Mail</small> </label>
                                <input class="form-control mr-sm-2 no-print" type="text" value="<?php echo e($user->email); ?>" readonly>
                            </div>
                            <div class="form-group my-2 mx-1 flex-fill">
                        <button class="text-white btn-theme no-print ml-1 mt-4" id="sendMail"  class="btn" >Send Mail</button>
                            </div>

                       </div>


                        </div>


                    </div>



                    <div class="overflow mt-2">
                        <h4 class="text-center my-3">STATEMENT</h4>

                        <?php if($fromDate !=""): ?>
                            <h5 class="text-center my-3">From  <?php echo e(Carbon::parse($fromDate)->format('d/m/Y')); ?> to  <?php echo e(Carbon::parse($toDate)->format('d/m/Y')); ?></h5>
                        <?php endif; ?>
                        <div class="overflow">
                            <table class="table table-custom shadow-sm bg-white">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Transaction Id</th>
                                        <th>transaction type</th>
                                        <th>Voucher Number</th>
                                        <th>Charity Name</th>
                                        <th>Status</th>
                                        <th>Credit</th>
                                        <th>Debit</th>
                                        <th>Balance</th>
                                    </tr>
                                </thead>

                            <?php
                                $tbalance = 0;
                            ?>

                              <?php $__currentLoopData = $tamount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($data->commission != 0): ?>
                                        <?php
                                        $tbalance = $tbalance - $data->commission;
                                        ?>
                                    <?php endif; ?>

                                    <?php
                                    if($data->t_type == "In"){
                                        if($data->commission != 0){

                                        $tbalance = $tbalance + $data->amount + $data->commission;
                                        }else {

                                        $tbalance = $tbalance + $data->amount;
                                        }

                                    }
                                    ?>
                                            <?php
                                            if($data->t_type == "Out"){
                                            $tbalance = $tbalance - $data->amount;
                                            }
                                            ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <tbody>
                                
                                <?php $__currentLoopData = $report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($data->commission != 0): ?>
                                    <tr>
                                        <td><?php echo e(Carbon::parse($data->created_at)->format('d/m/Y')); ?></td>
                                        <td><?php echo e($data->t_id); ?> </td>
                                        <td>Commission</td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td>-£<?php echo e($data->commission); ?></td>
                                        <td>£<?php echo e(number_format($tbalance, 2)); ?></td>
                                        <?php
                                        $tbalance = $tbalance + $data->commission;
                                        ?>
                                    </tr>
                                    <?php endif; ?>
                                    <tr>
                                        <td><?php echo e(Carbon::parse($data->created_at)->format('d/m/Y')); ?></td>
                                        <td><?php echo e($data->t_id); ?> </td>
                                        <td><?php echo e($data->title); ?> </td>
                                        <td><?php echo e($data->cheque_no); ?></td>
                                        <td><?php if($data->charity_id): ?><?php echo e($data->charity->name); ?><?php endif; ?></td>
                                        <td><?php if($data->pending == "0"): ?> Pending <?php endif; ?></td>

                                            <?php if($data->t_type == "In"): ?>
                                                <?php if($data->commission != 0): ?>
                                                    <td>£ <?php echo e(number_format($data->amount + $data->commission, 2)); ?> </td>
                                                    <td></td>
                                                    <td> £<?php echo e(number_format($tbalance, 2)); ?> </td>
                                                    <?php $tbalance = $tbalance - $data->amount - $data->commission; ?>
                                                <?php else: ?>
                                                    <td>£<?php echo e(number_format($data->amount, 2)); ?> </td>
                                                    <td></td>
                                                    <td> £<?php echo e(number_format($tbalance, 2)); ?> </td>
                                                    <?php $tbalance = $tbalance - $data->amount; ?>
                                                <?php endif; ?>
                                            <?php elseif($data->t_type == "Out"): ?>
                                                <td></td>
                                                <td>-£<?php echo e(number_format($data->amount, 2)); ?></td>
                                                 <td> £<?php echo e(number_format($tbalance, 2)); ?> </td>
                                                 <?php if($data->pending != "0"): ?>
                                                 <?php  $tbalance = $tbalance + $data->amount;  ?>
                                                 <?php endif; ?>
                                            <?php endif; ?>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 <tr>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td>Previous Balance</td>
                                    <td>£<?php echo e(number_format($tbalance, 2)); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </section>
    </div>
</div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script type="text/javascript">
$(document).ready(function() {


//header for csrf-token is must in laravel
$.ajaxSetup({ headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') } });
//

var url = "<?php echo e(URL::to('/admin/donor-report-mail')); ?>";


$("#sendMail").click(function(){

    $("#loading").show();

    var fromdate = $("#efromdate").val();
    var todate = $("#etodate").val();
    var user_id = $("#user_id").val();

        $.ajax({
            url: url,
            method: "POST",
            data: {fromdate,todate,user_id},

            success: function (d) {
                if (d.status == 303) {
                    $(".ermsg").html(d.message);
                    pagetop();
                }else if(d.status == 300){
                    $(".ermsg").html(d.message);
                    pagetop();
                }
            },
            complete:function(d){
                        $("#loading").hide();
                    },
            error: function (d) {
                console.log(d);
            }
        });

});

});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\server\htdocs\Laravel\tevini_charity\resources\views/donor/report.blade.php ENDPATH**/ ?>