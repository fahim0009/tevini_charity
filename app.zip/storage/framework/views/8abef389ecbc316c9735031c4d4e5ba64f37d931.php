<?php $__env->startComponent('mail::message'); ?>

<h3>Dear Mr <?php echo e($array['name']); ?>,</h3>

<p>Please find attached statement.</p>



Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\server\htdocs\Laravel\tevini_charity\resources\views/mail/donorreport.blade.php ENDPATH**/ ?>