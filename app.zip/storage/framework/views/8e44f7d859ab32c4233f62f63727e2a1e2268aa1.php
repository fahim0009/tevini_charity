[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH D:\server\htdocs\Laravel\tevini_charity\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>