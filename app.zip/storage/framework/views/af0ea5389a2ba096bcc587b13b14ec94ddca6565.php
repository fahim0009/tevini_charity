
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="UTF-8">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Tevini</title>
    <link href="<?php echo e(asset('assets/front/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/animate.min.css')); ?>" />
    <?php echo $__env->yieldContent('css'); ?>
</head>

<body>

    
    <?php echo $__env->make('frontend.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('frontend.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="<?php echo e(asset('assets/user/js/jquery-3.5.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/front/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/front/js/iconify.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/front/js/wow.min.js')); ?>"></script>
    <script src='<?php echo e(asset('assets/front/js/app.js')); ?>'> </script>
    <script>
        new WOW().init();
    </script>
    <?php echo $__env->yieldContent('script'); ?>

</body>

</html><?php /**PATH D:\server\htdocs\Laravel\tevini_charity\resources\views/frontend/layouts/master.blade.php ENDPATH**/ ?>