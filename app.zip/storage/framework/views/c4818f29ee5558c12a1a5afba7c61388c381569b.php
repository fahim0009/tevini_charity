<div class="leftSection wow fadeIn no-print" data-wow-delay=".25s" id='leftSidebar'>
    <div class="user-profile">
        <div class="close-dashboard-sidebar">
            <span class="iconify" onclick="foldSidebar();" data-icon="mdi:window-close"></span>
        </div>
        <img src="<?php echo e(asset('assets/image/logo/logo.png')); ?>" alt="">
    </div>
    <nav class="sidenav">
        <ul>
            <li class="nav-item <?php echo e((request()->is('admin/dashboard*')) ? 'active' : ''); ?>" id="admindashboard">
                <a href="<?php echo e(route('admin.dashboard')); ?>">
                    <span class="iconify" data-icon="clarity:dashboard-solid-badged"></span>
                    Dashboard
                </a>
            </li>
            <li class="nav-item <?php echo e((request()->is('admin/staff*')) ? 'active' : ''); ?>" id="admintransaction">
                <a href="<?php echo e(url('admin/staff')); ?>">
                    <span class="iconify" data-icon="icon-park-outline:transaction"></span>
                    Manage Admin
                </a>
            </li>
            <!--<li class="nav-item <?php echo e((request()->is('admin/role*')) ? 'active' : ''); ?>" id="admintransaction">-->
            <!--    <a href="<?php echo e(url('admin/role')); ?>">-->
            <!--        <span class="iconify" data-icon="icon-park-outline:transaction"></span>-->
            <!--        Staff Role-->
            <!--    </a>-->
            <!--</li>-->
            <li class="nav-item <?php echo e((request()->is('admin/transaction*')) ? 'active' : ''); ?>" id="">
                <a href="<?php echo e(route('transaction')); ?>">
                    <span class="iconify" data-icon="icon-park-outline:transaction"></span>
                    Latest Transactions
                </a>
            </li>
            <li class="nav-item <?php echo e((request()->is('admin/donor*')) ? 'active' : ''); ?>" id="">
                <a href="<?php echo e(route('donor')); ?>">
                    <span class="iconify" data-icon="icon-park-outline:transaction"></span>
                    Donor
                </a>
            </li>
            <li class="nav-item <?php echo e((request()->is('admin/charity*')) ? 'active' : ''); ?>" id="">
                <a href="<?php echo e(route('charitylist')); ?>">
                    <span class="iconify" data-icon="icon-park-outline:transaction"></span>
                    Charities
                </a>
            </li>
            <li class="nav-item <?php echo e((request()->is('admin/process-voucher*')) ? 'active' : ''); ?>" id="">
                <a href="<?php echo e(route('processvoucher')); ?>">
                    <span class="iconify" data-icon="icon-park-outline:transaction"></span>
                    Process Vouchers
                </a>
            </li>
            <li class="nav-item <?php echo e((request()->is('admin/complete-voucher*')) ? 'active' : ''); ?>" id="">
                <a href="<?php echo e(route('completevoucher')); ?>">
                    <span class="iconify" data-icon="icon-park-outline:transaction"></span>
                    Complete Vouchers
                </a>
            </li>
            <li class="nav-item <?php echo e((request()->is('admin/pending-voucher*')) ? 'active' : ''); ?>" id="">
                <a href="<?php echo e(route('pendingvoucher')); ?>">
                    <span class="iconify" data-icon="icon-park-outline:transaction"></span>
                    Pending Vouchers
                </a>
            </li>        

            <li class="nav-item <?php echo e((request()->is('admin/order*')) ? 'active' : ''); ?>">
                <a href="#">
                    <span class="iconify" data-icon="fluent:contact-card-28-regular"></span>
                    Voucher Order
                </a>
                <ul class="sub-item">
                    <li class="<?php echo e((request()->is('admin/order/new')) ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('neworder')); ?>">
                            <span class="iconify" data-icon="fluent:contact-card-28-regular"></span>
                            New Order list
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('completeorder')); ?>">
                            <span class="iconify" data-icon="fluent:contact-card-28-regular"></span>
                            Complete order list
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('cancelorder')); ?>">
                            <span class="iconify" data-icon="fluent:contact-card-28-regular"></span>
                            Cancel order list
                        </a>
                    </li>
                </ul>
            </li>



            

            <li class="nav-item <?php echo e((request()->is('admin/donationlist*')) ? 'active' : ''); ?>">
                <a href="#">
                    <span class="iconify" data-icon="fluent:contact-card-28-regular"></span>
                    Online Donation
                </a>
                <ul class="sub-item">
                    <li>
                        <a href="<?php echo e(route('donationlist')); ?>">
                            <span class="iconify" data-icon="fluent:contact-card-28-regular"></span>
                            New Donation
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('donationstanding')); ?>">
                            <span class="iconify" data-icon="fluent:contact-card-28-regular"></span>
                            Standing order
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('donationrecord')); ?>">
                            <span class="iconify" data-icon="fluent:contact-card-28-regular"></span>
                            Donation record
                        </a>
                    </li>
                </ul>
            </li>


            <li class="nav-item <?php echo e((request()->is('admin/commission*')) ? 'active' : ''); ?>" id="admintransaction">
                <a href="<?php echo e(route('commission')); ?>">
                    <span class="iconify" data-icon="icon-park-outline:transaction"></span>
                    Commission
                </a>
            </li>



            <li class="nav-item <?php echo e((request()->is('admin/voucher-book*')) ? 'active' : ''); ?>" id="admintransaction">
                <a href="<?php echo e(route('voucherbooks')); ?>">
                    <span class="iconify" data-icon="icon-park-outline:transaction"></span>
                    Voucher Books Stock
                </a>
            </li>
            <li class="nav-item <?php echo e((request()->is('admin/remittance*')) ? 'active' : ''); ?>" id="admintransaction">
                <a href="<?php echo e(route('remittance')); ?>">
                    <span class="iconify" data-icon="icon-park-outline:transaction"></span>
                    Remittance Reports
                </a>
            </li>
            

            <!--<li class="nav-item <?php echo e((request()->is('admin/settings*')) ? 'active' : ''); ?>" id="admintransaction">-->
            <!--    <a href="<?php echo e(route('admin.settings')); ?>">-->
            <!--        <span class="iconify" data-icon="icon-park-outline:transaction"></span>-->
            <!--        Settings-->
            <!--    </a>-->
            <!--</li>-->
            
            
            <li class="nav-item <?php echo e((request()->is('admin/admin-contact-mail*')) ? 'active' : ''); ?>" id="admintransaction">
                <a href="<?php echo e(route('admin.contactmail')); ?>">
                    <span class="iconify" data-icon="icon-park-outline:transaction"></span>
                    Contact Mail
                </a>
            </li>

            <li class="nav-item">
                <a href="#">
                    <span class="iconify" data-icon="fluent:contact-card-28-regular"></span>
                    About Us
                </a>
                <ul class="sub-item">
                    <li>
                        <a href="<?php echo e(route('about.help')); ?>">
                            <span class="iconify" data-icon="fluent:contact-card-28-regular"></span>
                            What we help
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('aboutcontent.show')); ?>">
                            <span class="iconify" data-icon="fluent:contact-card-28-regular"></span>
                            About Content
                        </a>
                    </li>
                </ul>
            </li>


            
            
        </ul>
    </nav>
</div>
<?php /**PATH D:\server\htdocs\Laravel\tevini_charity\resources\views/inc/admin_sidebar.blade.php ENDPATH**/ ?>