
<?php $__env->startSection('content'); ?>
<div class="dashboard-content">
    <section class="profile purchase-status">
        <div class="title-section">
            <span class="iconify" data-icon="icon-park-outline:transaction"></span> <div class="mx-2">Donor Details</div>
        </div>
    </section>
    <?php echo $__env->make('inc.user_menue', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
    <div class="rightSection">
        <div class="dashboard-content">
            <section class="profile purchase-status">
                <div class="title-section">
                    <span class="iconify" data-icon="fluent:contact-card-28-regular"></span>
                    <div class="mx-2">User Profiles (<?php echo e($donor_id); ?>)</div>
                </div>
            </section>
            <?php if(session()->has('message')): ?>
              <section class="px-4">
                  <div class="row my-3">
                      <div class="alert alert-success" id="successMessage"><?php echo e(session()->get('message')); ?></div>
                  </div>
              </section>
              <?php endif; ?>
              <?php if(session()->has('error')): ?>
              <section class="px-4">
                  <div class="row my-3">
                      <div class="alert alert-danger" id="errMessage"><?php echo e(session()->get('error')); ?></div>
                  </div>
              </section>
              <?php endif; ?>
            <section class="px-4">
                <div class="row my-3">
      
                  <form action="<?php echo e(route('user.update')); ?>" method="POST" enctype="multipart/form-data" >
                    <?php echo csrf_field(); ?>
                    <div class="col-md-12 ">
                        <div class="row mx-auto">
      
                            <div class="col-md-3 border-right">
                                <div class="d-flex flex-column align-items-center text-center p-3 py-5" style="position:relative">
                                    <img class="rounded-circle mt-5" width="150px"
                                        src="<?php if($profile_data->photo): ?><?php echo e(asset('images/'.$profile_data->photo)); ?><?php else: ?> https://st3.depositphotos.com/15648834/17930/v/600/depositphotos_179308454-stock-illustration-unknown-person-silhouette-glasses-profile.jpg <?php endif; ?>"><span
                                        class="font-weight-bold"><?php echo e($profile_data->name); ?></span>
                                        <span class="text-black-50"><?php echo e($profile_data->email); ?></span>
                                        <span> Balance : <?php echo e($profile_data->balance); ?></span>
                                        
                                </div>
                            </div>
                            <div class="col-md-5 border-right">
                                <div class="p-3 py-4 text-muted">
                                    <div class="row mt-2">
                                        <div class="col-md-6"><label><small>Name</small></label><input type="text"
                                                class="form-control" placeholder="first name" name="name" id="name" value="<?php echo e($profile_data->name); ?>" readonly="readonly"></div>
      
                                        <div class="col-md-6"><label><small>Surname</small></label><input
                                                type="text" class="form-control" name="surname" id="surname" value="<?php echo e($profile_data->surname); ?>" placeholder="surname" readonly="readonly">
                                        </div>
                                    </div>
                                    <div class="row mt-3">
                                        <div class="col-md-12 mb-3"><label><small>Mobile
                                                    Number</small></label><input type="text" class="form-control"
                                                placeholder="enter phone number" id="phone" name="phone" value="<?php echo e($profile_data->phone); ?>" readonly="readonly"></div>
      
                                        <div class="col-md-12 mb-3"><label><small>House No</small></label>
                                          <input type="text" class="form-control" placeholder="enter address" name="houseno" id="houseno" value="<?php echo e($profile_data->houseno); ?>" readonly="readonly">
                                          </div>
                                          
                                              <div class="col-md-12 mb-3"><label><small>Street</small></label>
                                          <input type="text" class="form-control" placeholder="Street number" name="street" id="street" value="<?php echo e($profile_data->street); ?>" readonly="readonly">
                                          </div>
      
      
                                        <div class="col-md-12 mb-3"><label><small>Town</small></label><input type="text" class="form-control" placeholder="enter town" name="town" id="town" value="<?php echo e($profile_data->town); ?>" readonly="readonly"></div>
      
                                        <div class="col-md-12 mb-3"><label><small>Postcode</small></label><input
                                                type="text" class="form-control" id="postcode" name="postcode" placeholder="enter postcode" value="<?php echo e($profile_data->postcode); ?>" readonly="readonly"></div>
      
                                        <div class="col-md-12 mb-3"><label><small>Email ID</small></label><input
                                                type="email" class="form-control" id="email" name="email" placeholder="enter email id" value="<?php echo e($profile_data->email); ?>" readonly="readonly"></div>
      
      
                                        
                                    </div>      
                                    
                                </div>
                            </div>
      
      
                        </div>
                    </div>
      
      
                  </form>
                </div>
            </section>
        </div>
      </div>
    
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>


<script type="text/javascript">
  $(document).ready(function() {
      $("#profileinfo").addClass('active');
      $("#profileinfo").addClass('is-expanded');
      $("#profile").addClass('active');
  });
</script>


<script type="text/javascript">

    $(document).ready(function () {

        $(".updateBtn").hide();


        $("body").delegate(".editBtn","click",function(event){
            event.preventDefault();
            $("#name").attr("readonly", false);
            $("#surname").attr("readonly", false);
            $("#phone").attr("readonly", false);
            $("#houseno").attr("readonly", false);
            $("#street").attr("readonly", false);
            $("#town").attr("readonly", false);
            $("#postcode").attr("readonly", false);
            $("#email").attr("readonly", false);
            $("#password").attr("readonly", false);
            $("#cpassword").attr("readonly", false);
            $("#editBtn").hide();
            $("#updateBtn").show();
        });



})

</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\server\htdocs\Laravel\tevini_charity\resources\views/donor/profile.blade.php ENDPATH**/ ?>