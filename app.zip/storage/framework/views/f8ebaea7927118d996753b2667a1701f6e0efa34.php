<?php $__env->startSection('content'); ?>



<div class="rightSection">

    <div class="dashboard-content">

        <section class="profile purchase-status">
            <div class="title-section">
                <span class="iconify" data-icon="fluent:contact-card-28-regular"></span>
                <div class="mx-2"> Contact Mail Email </div>
            </div>
        </section>





        <?php if(session()->has('message')): ?>
        <section class="px-4">
            <div class="row my-3">
                <div class="alert alert-success" id="successMessage"><?php echo e(session()->get('message')); ?></div>
            </div>
        </section>
        <?php endif; ?>
        <?php if(session()->has('error')): ?>
        <section class="px-4">
            <div class="row my-3">
                <div class="alert alert-danger" id="errMessage"><?php echo e(session()->get('error')); ?></div>
            </div>
        </section>
        <?php endif; ?>




        <section class="px-4"  id="contentContainer">
            <div class="row my-3">

                <div class="col-md-12 mt-2 text-center">
                    <div class="overflow">
                        <table class="table table-custom shadow-sm bg-white">
                            <thead>
                                <tr>
                                    <th>Sl</th>
                                    <th>Email</th>
                                    <th>Action </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $n = 1;
                                ?>
                                <?php $__empty_1 = true; $__currentLoopData = $contactmail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($n++); ?></td>
                                        <td><?php echo e($data->name); ?></td>
                                        <td>
                                        <a href="<?php echo e(route('contactmail.edit', $data->id)); ?>"><i class="fa fa-edit" style="color: #2196f3;font-size:16px;"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>




                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>


    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
    $(document).ready(function () {


        $("#addThisFormContainer").hide();
        $("#newBtn").click(function(){
            clearform();
            $("#newBtn").hide(100);
            $("#addThisFormContainer").show(300);

        });
        $("#FormCloseBtn").click(function(){
            $("#addThisFormContainer").hide(200);
            $("#newBtn").show(100);
            clearform();
        });

        function clearform(){
                $('#createThisForm')[0].reset();
            }

            setTimeout(function() {
                $('#successMessage').fadeOut('fast');
                $('#errMessage').fadeOut('fast');
            }, 3000);





    });





</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\server\htdocs\Laravel\tevini_charity\resources\views/contact/contactmail.blade.php ENDPATH**/ ?>